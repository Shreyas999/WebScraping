# -*- coding: utf-8 -*-
"""
Created on Thu Apr 30 11:10:08 2020

@author: Shreyas K
"""
import os
from bs4 import BeautifulSoup
import scrapy
import re
   
class MySpider(scrapy.Spider):
    name = "bmsce"
    def __init__(self, *args, **kwargs):
        super(MySpider, self).__init__(*args, **kwargs)
        self.start_urls = [kwargs.get('url')] 	
        f=os.listdir('scrapeddata')
        for i in f:
            os.remove('scrapeddata/%s'%i)
    custom_settings = {
        'DEPTH_LIMIT': 1
    }  
    def parse(self, response):
        # use lxml to get decent HTML parsing speed
        soup = BeautifulSoup(response.text, 'lxml')
        #links= response.css('a::attr(href).text').getall()
        links=response.xpath('//aside//a/@href').getall()
        #yield {
         #   "url": response.url,
          #  "title": soup.h1.string}
        
        head=response.xpath('//div//h1/text()').get()
        inp=soup.find_all("div", class_="col-lg-9")
        data=""
        for i in inp:
            data1=i.get_text()
            #data1=' '.join(data1.split())
            data+="\n"+data1
        data=re.sub('\n+','\n',data)

        #data=head+data
        with open('scrapeddata/%s.txt'%head,'w+',encoding='utf-8') as f:
            f.write(data+"\n\n")
        linklist=[]
        for i in links:
            if i[0]=='[' or len(i)==1:
                pass
            else:
                data=data+i+"\n"
                linklist.append(i)
        #data=re.sub('\n+','\n',data)
        '''with open('data.txt','a+',encoding='utf-8') as f:
            f.write(data.strip())'''
        for next_page in linklist:
            yield scrapy.Request(response.urljoin(next_page),callback=self.parse)
#os.system('cmd /c "scrapy crawl spbs"')            
