"""
Created on Wed Mar 18 10:04:51 2020

@author: Shreyas K
"""
#Extract all links in a webpage         
import os
from bs4 import BeautifulSoup
import scrapy
import re

class BSSpider(scrapy.Spider):
    name = "bms"
    
    start_urls = ['https://bmsce.ac.in/home/About-BMSCE']
    #'https://www.bbc.com/news/topics/cljevyzxlelt/us-immigration'
    custom_settings = {
        'DEPTH_LIMIT': 1
    }
    def parse(self, response):
        # use lxml to get decent HTML parsing speed
        soup = BeautifulSoup(response.text, 'lxml')
        #links= response.css('a::attr(href).text').getall()
        #links=response.xpath('//aside//a/@href').getall()
        inp=soup.find_all("div", class_="col-lg-9")
        data=""
        for i in inp:
            data+=i.get_text()
        data=data.replace('\n+','\n')
        with open('bmsdata.txt','w',encoding='utf-8') as f:
            f.write(data)
#os.system('cmd /c "scrapy crawl spbs"')            

