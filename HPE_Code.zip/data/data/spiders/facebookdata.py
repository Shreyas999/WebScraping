# -*- coding: utf-8 -*-
"""
Created on Thu Apr 30 11:10:08 2020

@author: Shreyas K
"""

import os
from bs4 import BeautifulSoup
import scrapy
import re
   
class MySpider(scrapy.Spider):
    name = "facebook"
    def __init__(self,url=None, *args, **kwargs):
        super(MySpider, self).__init__(*args, **kwargs)
        self.start_urls = ['https://www.facebook.com/pg/johncena/posts/?ref=page_internal']
		#self.start_urls = ['https://en.wikipedia.org/wiki/Table_(information)']#['%s' % url]	
		#allowed_domains = ["example.com"]
    def parse(self, response):
        # use lxml to get decent HTML parsing speed
        soup = BeautifulSoup(response.text, 'lxml')
        #yield {
         #   "url": response.url,
          #  "title": soup.h1.string}
        inp=""
        inp=soup.find_all('p')  
        data=""
        for i in inp:
            data1=i.get_text()
            #data1=' '.join(data1.split())
            data+="\n"+data1
        data=re.sub('\n+','\n',data)
        with open('facebook.txt','w',encoding='utf-8') as f:
            f.write(data.strip())
			


#os.system('cmd /k "scrapy crawl wiki"')# -a url=https://bmsce.ac.in/home/About-BMSCE"')
#'https://www.bbc.com/news/world-us-canada-52363852'
#https://bmsce.ac.in/home/About-BMSCE
#https://en.wikipedia.org/wiki/University