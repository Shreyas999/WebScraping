import os
import random
urlin=input("Enter url:")
#url="https://bmsce.ac.in/home/About-BMSCE"
#os.system('cmd /k "scrapy crawl bmsce -a url=%s "'%url)
#os.system('cmd /k "scrapy crawl bmsce"')# -a url=https://www.facebook.com/pg/johncena/posts/?ref=page_internal"')
#https://bmsce.ac.in/home/About-BMSCE
#https://www.wwe.com/superstars/john-cena/
'''websites=['facebook','bmsce','wikipedia','hpe']
ch=random.choice(websites)
if ch=='wikipedia':
	os.system('cmd /k "scrapy crawl wiki"')
elif ch=='bmsce':
	os.system('cmd /k "scrapy crawl bmsce"')
elif ch=='hpe':
	os.system('cmd /k "scrapy crawl hpe"')
else:
	os.system('cmd /k "scrapy crawl facebook"')'''
if 'facebook' in urlin.lower():
	print("Facebook")
	os.system('cmd /k "scrapy crawl facebook -a url=%s "'%urlin)
elif 'bmsce' in urlin.lower():
	print("BMSCE")
	os.system('cmd /k "scrapy crawl bmsce -a url=%s "'%urlin)
elif 'wikipedia' in urlin.lower():
	print("Wikipedia")
	os.system('cmd /k "scrapy crawl wiki -a url=%s "'%urlin)
elif 'hpe' in urlin.lower():
	print("HPE")
	os.system('cmd /k "scrapy crawl hpe -a url=%s "'%urlin)
else:
	print("Something else")
	