# -*- coding: utf-8 -*-
"""
Created on Thu Apr 30 11:10:08 2020

@author: Shreyas K
"""

import os
from bs4 import BeautifulSoup
import scrapy
import re
   
class MySpider(scrapy.Spider):
    name = "bmsce"
    def __init__(self, *args, **kwargs):
        super(MySpider, self).__init__(*args, **kwargs)
        self.start_urls = [kwargs.get('url')] 	
        
    def parse(self, response):
        # use lxml to get decent HTML parsing speed
        soup = BeautifulSoup(response.text, 'lxml')
        #yield {
         #   "url": response.url,
          #  "title": soup.h1.string}
        inp=""
        inp=soup.find_all('p')   
        data=""
        for i in inp:
            data1=i.get_text()
            data1=' '.join(data1.split())
            data+="\n"+data1
        data=re.sub('\n+','\n',data)
        with open('bmsce.txt','w+',encoding='utf-8') as f:
            f.write(data.strip())
#self.start_urls = ['https://bmsce.ac.in/home/Under-Graduation']
#self.start_urls=['%s'% url]	
#allowed_domains = ["example.com"]
#https://bmsce.ac.in/home/About-BMSCE