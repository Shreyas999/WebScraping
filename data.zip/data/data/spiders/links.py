"""
Created on Wed Mar 18 10:04:51 2020

@author: Shreyas K
"""
#Extract all links in a webpage         
import os
from bs4 import BeautifulSoup
import scrapy
import re

class BSSpider(scrapy.Spider):
    name = "spbs"
    with open('bmsce.txt','w') as f:
        f.write("")
    start_urls = ['https://bmsce.ac.in/home/Under-Graduation']
    #'https://www.bbc.com/news/topics/cljevyzxlelt/us-immigration'
    custom_settings = {
        'DEPTH_LIMIT': 1
    }
    def parse(self, response):
        # use lxml to get decent HTML parsing speed
        soup = BeautifulSoup(response.text, 'lxml')
        #links= response.css('a::attr(href).text').getall()
        links=response.xpath('//aside//a/@href').getall()
        #yield {
         #   "url": response.url,
          #  "title": soup.h1.string}
        
        #inp=soup.find_all('p')
        #if 'about' in response.xpath('//div//h1/text()').get().lower() or 'bmsce' in response.xpath('//div//h1/text()').get().lower():
        head=response.xpath('//div//h1/text()').get()
        inp=soup.find_all("div", class_="col-lg-9")
        data=""
        for i in inp:
            data1=i.get_text()
            #data1=' '.join(data1.split())
            data+="\n"+data1
        data=re.sub('\n+','\n',data)
        '''with open('%s.txt'%head,'r',encoding='utf-8') as f:
            fdata=f.read()
        if data in fdata:
            pass
        else:'''
        #data=head+data
        with open('%s.txt'%head,'w+',encoding='utf-8') as f:
            f.write(data+"\n\n")
        linklist=[]
        for i in links:
            if i[0]=='[' or len(i)==1:
                pass
            else:
                data=data+i+"\n"
                linklist.append(i)
        #data=re.sub('\n+','\n',data)
        '''with open('data.txt','a+',encoding='utf-8') as f:
            f.write(data.strip())'''
        for next_page in linklist:
            yield scrapy.Request(response.urljoin(next_page),callback=self.parse)
#os.system('cmd /c "scrapy crawl spbs"')            

