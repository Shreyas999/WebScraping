# -*- coding: utf-8 -*-
"""
Created on Thu Apr 30 11:10:08 2020

@author: Shreyas K
"""

import os
from bs4 import BeautifulSoup
import scrapy
import re
   
class MySpider(scrapy.Spider):
     name = "wiki"
     def __init__(self, *args, **kwargs):
        super(MySpider, self).__init__(*args, **kwargs)
        #self.start_urls = [kwargs.get('url')]
        with open('wikipedia.txt','w') as f:
            f.write("")
        self.start_urls = ['https://en.wikipedia.org/wiki/Machine_learning']#['%s' % url]	
		#allowed_domains = ["example.com"]
     def parse(self, response):
        # use lxml to get decent HTML parsing speed
        soup = BeautifulSoup(response.text, 'lxml')
        #yield {
         #   "url": response.url,
          #  "title": soup.h1.string}
        inp=""
        inp=soup.find_all('p')   
        #inptable=soup.find_all('table')
        #inp=inpp+inptable
        data=""
        for i in inp:
            data1=i.get_text()
            data1=' '.join(data1.split())
            data+="\n"+data1
        #data=re.sub('\n+','\n',data)
        data=data.strip()
        data+="\n\n"
        with open('wikipedia.txt','a+',encoding='utf-8') as f:
            f.write(data)
        #NEXT_PAGE_SELECTOR = '.next a ::attr(href)'
        #next_page = response.css(NEXT_PAGE_SELECTOR).extract_first()
        next_page='https://en.wikipedia.org/wiki/University'
        if next_page:
            yield scrapy.Request(response.urljoin(next_page),callback=self.parse)
        
        #self.start_urls.append('https://bmsce.ac.in/home/About-BMSCE')
#os.system('cmd /k "scrapy crawl wiki"')# -a url=https://bmsce.ac.in/home/About-BMSCE"')
#'https://www.bbc.com/news/world-us-canada-52363852'
#https://bmsce.ac.in/home/About-BMSCE
#https://en.wikipedia.org/wiki/University