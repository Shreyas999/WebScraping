import io
from pdfminer.converter import TextConverter
from pdfminer.pdfinterp import PDFPageInterpreter
from pdfminer.pdfinterp import PDFResourceManager
from pdfminer.pdfpage import PDFPage
import os

def extract_text_from_pdf(pdf_path):
    resource_manager = PDFResourceManager()
    fake_file_handle = io.StringIO()
    converter = TextConverter(resource_manager, fake_file_handle)
    page_interpreter = PDFPageInterpreter(resource_manager, converter)
    
    with open(pdf_path, 'rb') as fh:
        for page in PDFPage.get_pages(fh, 
                                      caching=True,
                                      check_extractable=True):
            page_interpreter.process_page(page)
            
        text = fake_file_handle.getvalue()    
    
    converter.close()
    fake_file_handle.close()
    print()
    print(text)

def extract_text_from_txt(filename):
    myfile=open(filename,"rt")
    contents=myfile.read()
    myfile.close()
    print()
    print(contents)

def extract_data_from_web(name):
    urlin=name
    if 'facebook' in urlin.lower():
        print("Facebook")
        os.system('cmd /k "scrapy crawl facebook -a url=%s "'%urlin)
    elif 'bmsce' in urlin.lower():
	    print("BMSCE")
	    os.system('cmd /k "cd data & scrapy crawl bmsce -a url=%s "'%urlin)
    elif 'wikipedia' in urlin.lower():
	    print("Wikipedia")
	    os.system('cmd /k "scrapy crawl wiki -a url=%s "'%urlin)
    elif 'hpe' in urlin.lower():
        print("HPE")
        os.system('cmd /k "scrapy crawl hpe -a url=%s "'%urlin)
    else:
        print("Something else")
	
    
if __name__ == '__main__':
    name=input("Enter file name with extension (or enter url):")
    p=name[-3::]
    if(p=="pdf"):
        extract_text_from_pdf(name)
    elif(p=="txt"):
        extract_text_from_txt(name)
    else:
        extract_data_from_web(name)